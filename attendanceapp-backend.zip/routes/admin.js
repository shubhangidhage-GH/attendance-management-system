// routes/admin.js
const express = require('express');
const router = express.Router();
const Attendance = require('../models/Attendance');

router.get('/attendance-grid', async (req, res) => {
  try {
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth(); // 0-indexed
    const currentDay = today.getDate(); // today's day (e.g., 8)

    const startOfMonth = new Date(year, month, 1);
    const endOfMonth = new Date(year, month + 1, 0);

    const attendanceRecords = await Attendance.find({
      date: { $gte: startOfMonth, $lte: endOfMonth },
    });

    const usersMap = new Map();

    attendanceRecords.forEach((record) => {
      const key = record.email;
      if (!usersMap.has(key)) {
        usersMap.set(key, {
          name: record.name,
          email: record.email,
          attendanceDates: [],
        });
      }
      usersMap.get(key).attendanceDates.push(record.date.toISOString().split('T')[0]);
    });

    const users = Array.from(usersMap.values());

    const datesArray = [];
    for (let d = 1; d <= currentDay; d++) {
      const dateStr = new Date(year, month, d).toISOString().split('T')[0];
      datesArray.push(dateStr);
    }

    const gridData = users.map((user) => {
      const row = {
        name: user.name,
        email: user.email,
      };

      let presentCount = 0;

      datesArray.forEach((date) => {
        const isPresent = user.attendanceDates.includes(date);
        row[date] = isPresent ? '✓' : '✗';
        if (isPresent) presentCount++;
      });

      row.percentage = `${((presentCount / datesArray.length) * 100).toFixed(1)}%`;

      return row;
    });

    res.json({ dates: datesArray, users: gridData });
  } catch (error) {
    console.error('Error loading admin grid:', error);
    res.status(500).json({ error: 'Failed to load attendance grid' });
  }
});

module.exports = router;
