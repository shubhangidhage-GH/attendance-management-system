const express = require('express');
const router = express.Router();
const Attendance = require('../models/Attendance');

// Health check route (optional)
router.get('/', (req, res) => {
  res.send('Attendance API Running');
});

// POST - Mark attendance
router.post('/mark', async (req, res) => {
  const { uid, name, email } = req.body;
  if (!uid || !name || !email) {
    return res.status(400).json({ error: 'Missing UID, name, or email' });
  }

  const start = new Date();
  start.setHours(0, 0, 0, 0);
  const end = new Date();
  end.setHours(23, 59, 59, 999);

  const existing = await Attendance.findOne({
    uid,
    date: { $gte: start, $lte: end }
  });

  if (existing) return res.status(400).json({ message: 'Attendance already marked for today' });

  const now = new Date();
  const time = now.toLocaleTimeString('en-US', { hour12: true });

  const attendance = new Attendance({
    uid,
    name,
    email,
    date: now,
    time
  });

  await attendance.save();
  res.status(200).json({ message: 'Attendance marked' });
});

// GET - Get attendance history by UID
router.get('/history/:uid', async (req, res) => {
  const { uid } = req.params;
  const records = await Attendance.find({ uid }).sort({ date: 1 });
  res.json(records);
});

// GET - All attendance records
router.get('/all', async (req, res) => {
  try {
    const records = await Attendance.find().sort({ date: -1 });
    res.json(records);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch records' });
  }
});

module.exports = router;
