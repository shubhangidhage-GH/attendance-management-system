import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
const firebaseConfig = {
    apiKey: "AIzaSyA0vDO5Sj-UQa2R62njB0AELkeeza53AIU",
    authDomain: "attendanceapp-d3e4c.firebaseapp.com",
    projectId: "attendanceapp-d3e4c",
    storageBucket: "attendanceapp-d3e4c.firebasestorage.app",
    messagingSenderId: "739781345402",
    appId: "1:739781345402:web:59540d2e34606b55357bc3"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

