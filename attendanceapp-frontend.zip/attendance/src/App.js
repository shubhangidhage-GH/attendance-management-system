import React, { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import Dashboard from './components/Dashboard';
import AttendanceHistory from './components/AttendanceHistory';
import Layout from './components/Layout';
import About from './components/About';
import Profile from './components/Profile';
import './App.css';
import AdminLogin from './components/AdminLogin';
import AdminDashboard from './components/AdminDashboard';
function App() {
  const [user, setUser] = useState(null);

  // Handle logout
  const handleLogout = () => {
    setUser(null);
    alert("🚪 Logged out successfully!");
  };

  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/" element={<Login onLogin={setUser} />} />
      <Route path="/login" element={<Login onLogin={setUser} />} />
      <Route path="/register" element={<Register />} />
      <Route path="/admin-login" element={<AdminLogin />} />
     <Route path="/admin-dashboard" element={<AdminDashboard />} />
     


      {/* Protected Routes with Layout */}
      <Route element={<Layout user={user} onLogout={handleLogout} />}>
        <Route
          path="/dashboard"
          element={user ? <Dashboard user={user} /> : <Navigate to="/login" />}
        />
        <Route
          path="/history"
          element={user ? <AttendanceHistory /> : <Navigate to="/login" />}
        />
        <Route
          path="/profile"
          element={user ? <Profile /> : <Navigate to="/login" />}
        />
        <Route
          path="/about"
          element={user ? <About /> : <Navigate to="/login" />}
        />
      </Route>
    </Routes>
  );
}

export default App;
