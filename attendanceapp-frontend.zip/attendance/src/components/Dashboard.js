import React from 'react';
import { auth } from '../firebase';

function Dashboard() {
  const user = auth.currentUser;
  

  const handleMarkAttendance = async () => {
    if (!user) return alert('User not logged in');

    const response = await fetch(`http://localhost:5000/api/attendance/mark`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        uid: user.uid,
        name: user.displayName || 'N/A',
        email: user.email
      })
    });

    const data = await response.json();
    alert(data.message || data.error);
  };

  return (
    <div className="container mt-5">
      <div className="card shadow-lg border-0">
        <div className="card-header bg-primary text-white text-center">
          <h2> Welcome to the Attendance App</h2>
        </div>
        <div className="card-body text-center">
          <h4 className="mb-4">Hello, <span className="text-success">{user?.displayName || user?.email}</span></h4>
          
          <p className="lead">Click below to mark your attendance for today.</p>

          <button className="btn btn-success btn-lg mt-3" onClick={handleMarkAttendance}>
            ✅ Mark Attendance
          </button>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
