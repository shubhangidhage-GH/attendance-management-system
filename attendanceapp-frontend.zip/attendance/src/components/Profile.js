import React, { useEffect, useState } from 'react';
import { auth } from '../firebase';

export default function Profile() {
  const [records, setRecords] = useState([]);
  const [presentDates, setPresentDates] = useState([]);
  const [absentDates, setAbsentDates] = useState([]);
   
  useEffect(() => {
    const fetchData = async () => {
      const user = auth.currentUser;
      if (!user) return;

      const res = await fetch(`http://localhost:5000/api/attendance/history/${user.uid}`);
      const data = await res.json();

      const today = new Date();
      const allDates = [];

      for (let d = new Date(today.getFullYear(), today.getMonth(), 1); d <= today; d.setDate(d.getDate() + 1)) {
        allDates.push(new Date(d));
      }

      const present = data.map(d => new Date(d.date).toDateString());
      const absent = allDates
        .map(d => d.toDateString())
        .filter(d => !present.includes(d));

      setRecords(data);
      setPresentDates(present);
      setAbsentDates(absent);
    };

    fetchData();
  }, []);

  const user = auth.currentUser;


  return (
  <div className="profile-container">
    <div className="profile-card card shadow-lg">
      <div className="card-header bg-primary text-white text-center">
        <h2>👋 Welcome to Attendance App</h2>
        <h5>{user?.displayName || user?.email}</h5>
      </div>

      <div className="card-body">
        <h4 className="mb-3 text-secondary">📋 User Details</h4>
       <table className="table table-borderless">
  <tbody>
    <tr><th>Name:</th><td>{user?.displayName || "N/A"}</td></tr>
    <tr><th>Email:</th><td>{user?.email}</td></tr>
    <tr><th>Attendance %:</th><td>{Math.round((presentDates.length / (presentDates.length + absentDates.length)) * 100)}%</td></tr>
    <tr><th>Present Days:</th><td>{presentDates.length}</td></tr>
  </tbody>
</table>


        <h5 className="text-success mt-4">✅ Present Dates</h5>
        <div className="table-responsive">
          <table className="table table-sm table-hover table-bordered">
            <thead className="table-success">
              <tr><th>#</th><th>Date</th></tr>
            </thead>
            <tbody>
              {presentDates.map((date, i) => (
                <tr key={i}><td>{i + 1}</td><td>{date}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
);
}
