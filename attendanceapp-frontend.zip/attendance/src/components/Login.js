// src/components/Login.js
import { Link, useNavigate } from 'react-router-dom';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../firebase';
import React, { useState } from 'react';

export default function Login({ onLogin }) {
  const [email, setEmail]     = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const { user } = await signInWithEmailAndPassword(auth, email, password);
      onLogin(user);
      navigate('/dashboard');
    } catch {
      alert('Login failed');
    }
  };

  return (
    <div className="d-flex justify-content-center align-items-center vh-100">
      <div className="card p-4" style={{ width: 360 }}>
        <h2 className="text-center mb-4">User Login</h2>

        <input
          className="form-control mb-2"
          placeholder="Email"
          value={email}
          onChange={e => setEmail(e.target.value)}
        />
        <input
          type="password"
          className="form-control mb-3"
          placeholder="Password"
          value={password}
          onChange={e => setPassword(e.target.value)}
        />

        <button className="btn btn-success w-100 mb-2" onClick={handleLogin}>
          Sign In
        </button>

        <div className="text-center">
          <Link to="/register">Register</Link>
        </div>
        <div className="text-center mt-2">
          <Link to="/admin-login">🔑 Admin Login</Link>
        </div>
      </div>
    </div>
  );
}
