
import { useNavigate } from 'react-router-dom';
import { useState } from 'react';


const Logout = () => {
  const navigate = useNavigate();
  const [showConfirm, setShowConfirm] = useState(false);

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  return (
    <>
      <button className="logout-btn" onClick={() => setShowConfirm(true)}>
        Logout
      </button>

      {showConfirm && (
        <div className="confirm-overlay">
          <div className="confirm-box">
            <p>Are you sure you want to logout?</p>
            <div className="btn-group">
              <button className="btn btn-danger" onClick={handleLogout}>
                Yes
              </button>
              <button className="btn btn-secondary" onClick={() => setShowConfirm(false)}>
                No
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Logout;
