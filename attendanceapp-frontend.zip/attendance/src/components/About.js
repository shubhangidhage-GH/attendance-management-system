
import { useNavigate } from 'react-router-dom';

export default function About() {
  const navigate = useNavigate();

  return (
    <div className="about-container">
      <div className="about-card shadow-lg">
        <h2 className="text-primary mb-4">📘 About This Attendance System</h2>
        <p>
          Our Attendance System is built to simplify daily attendance marking and management for both users and administrators.
          It integrates secure login, real-time attendance tracking, user profiles, and insightful reports.
        </p>
        <ul className="feature-list">
          <li> Secure Firebase Authentication</li>
          <li>Daily Attendance Tracking (One click)</li>
          <li> Profile Dashboard with Attendance %</li>
          <li>History Log of Present/Absent Days</li>
          
        </ul>
        <p>
          This system is ideal for students, teams, or companies who want an efficient way to monitor presence and boost accountability.
        </p>

        <button onClick={() => navigate('/dashboard')} className="btn btn-outline-primary mt-3">
          ⬅ Back to Dashboard
        </button>
      </div>
    </div>
  );
}
