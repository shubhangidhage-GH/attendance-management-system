// AdminDashboard.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function AdminDashboard() {
  const [data, setData] = useState([]);
  const [dates, setDates] = useState([]);
  

  useEffect(() => {
    axios.get(`http://localhost:5000/admin/attendance-grid`)


      .then((res) => {
        setData(res.data.users || []);
        setDates(res.data.dates || []);
      })
      .catch((err) => console.error(err));
  }, );

  return (
    <div className="container mt-4">
      <h2>📊 All User's Attendance Review</h2>
      <div className="table-responsive">
        <table className="table table-bordered text-center">
          <thead className="table-primary">
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Email</th>
              {dates.map((d, i) => (
                <th key={i}>{new Date(d).getDate()}</th>
              ))}
              <th>% Present</th>
            </tr>
          </thead>
          <tbody>
            {data.map((user, idx) => (
              <tr key={idx}>
                <td>{idx + 1}</td>
                <td>{user.name}</td>
                <td>{user.email}</td>
                {dates.map((date, i) => (
                  <td key={i}>{user[date]}</td>
                ))}
                <td><strong>{user.percentage}</strong></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
