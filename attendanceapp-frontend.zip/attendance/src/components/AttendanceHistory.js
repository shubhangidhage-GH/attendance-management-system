import React, { useEffect, useState } from 'react';
import { auth } from '../firebase';

function AttendanceHistory() {
  const [records, setRecords] = useState([]);
  


  useEffect(() => {
    const fetchHistory = async () => {
      const user = auth.currentUser;
      if (!user) return;

      const res = await fetch(`http://localhost:5000/api/attendance/history/${user.uid}`);
      const data = await res.json();
      setRecords(data);
    };

    fetchHistory();
  }, []);

  return (
  <div className="history-card mt-5">
    <div className="card shadow p-4">
      <h3 className="text-center text-primary mb-4">📅 Attendance History</h3>
      <div className="table-responsive">
        <table className="table table-bordered table-striped table-hover">
          <thead className="table-primary">
            <tr>
              <th>#</th>
              <th>Date</th>
              <th>Marked At</th>
            </tr>
          </thead>
          <tbody>
            {records.map((r, i) => (
              <tr key={i}>
                <td>{i + 1}</td>
                <td>{new Date(r.date).toDateString()}</td>
                <td>{r.time}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  </div>


  );
}

export default AttendanceHistory;
