// src/components/AdminLogin.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function AdminLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = () => {
    
    if (email === 'admin@example.com' && password === 'admin123') {
      localStorage.setItem('isAdmin', 'true');
      navigate('/admin-dashboard');     
      alert('login successfully');
    }
  };

  return (
    <div className="container mt-5" style={{maxWidth: '400px'}}>
      <h2 className="mb-4 text-center">🔐 Admin Login</h2>
      <input
        type="email"
        className="form-control mb-2"
        placeholder="Admin Email"
        value={email}
        onChange={e => setEmail(e.target.value)}
      />
      <input
        type="password"
        className="form-control mb-3"
        placeholder="Password"
        value={password}
        onChange={e => setPassword(e.target.value)}
      />
      <button className="btn btn-dark w-100" onClick={handleLogin}>
        Login
      </button>
    </div>
  );
}
